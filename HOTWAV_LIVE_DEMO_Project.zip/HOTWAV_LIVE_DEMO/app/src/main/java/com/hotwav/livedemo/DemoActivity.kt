package com.hotwav.livedemo

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.VideoView
import android.widget.MediaController

class DemoActivity : Activity() {
    private lateinit var video: VideoView
    private lateinit var info: TextView
    private val prefs by lazy { getSharedPreferences("demo", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility =
            (View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
            setBackgroundColor(0xFF101820.toInt())
        }
        info = TextView(this).apply {
            text = "HOTWAV LIVE DEMO\nاختر فيديو من المعرض لبدء العرض"
            textSize = 20f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 0, 0, 22)
        }
        val choose = Button(this).apply {
            text = "اختيار فيديو من المعرض"
            setOnClickListener { pickVideo() }
        }
        val play = Button(this).apply {
            text = "تشغيل الفيديو المحفوظ"
            setOnClickListener { playSaved() }
        }
        val usePhone = Button(this).apply {
            text = "السماح باستخدام الهاتف"
            setOnClickListener {
                startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME))
            }
        }
        val enableService = Button(this).apply {
            text = "إعداد العودة التلقائية (إمكانية الوصول)"
            setOnClickListener {
                startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        video = VideoView(this)
        layout.addView(info)
        layout.addView(choose)
        layout.addView(play)
        layout.addView(usePhone)
        layout.addView(enableService)
        layout.addView(video, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        setContentView(layout)
        playSaved()
    }

    private fun pickVideo() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, 101)
    }

    @Deprecated("Deprecated in Android but supported for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 101 && resultCode == RESULT_OK) {
            data?.data?.let { uri ->
                try {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) {}
                prefs.edit().putString("video_uri", uri.toString()).apply()
                startVideo(uri)
            }
        }
    }

    private fun playSaved() {
        val saved = prefs.getString("video_uri", null)
        if (saved == null) {
            info.text = "لا يوجد فيديو محفوظ. اضغط اختيار فيديو من المعرض."
            return
        }
        startVideo(Uri.parse(saved))
    }

    private fun startVideo(uri: Uri) {
        info.text = "HOTWAV LIVE DEMO — العرض يعمل"
        video.setVideoURI(uri)
        video.setOnPreparedListener { player ->
            player.isLooping = true
            video.start()
        }
        video.setOnErrorListener { _, _, _ ->
            info.text = "تعذر تشغيل الفيديو. اختر ملف MP4 آخر."
            true
        }
    }
}
