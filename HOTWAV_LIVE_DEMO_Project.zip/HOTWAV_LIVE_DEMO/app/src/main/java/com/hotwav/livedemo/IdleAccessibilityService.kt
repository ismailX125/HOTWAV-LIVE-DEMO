package com.hotwav.livedemo

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class IdleAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private val returnToDemo = Runnable {
        val intent = Intent(this, DemoActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        try { startActivity(intent) } catch (_: Exception) {}
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val packageName = event.packageName?.toString() ?: return
        if (packageName == applicationContext.packageName) {
            handler.removeCallbacks(returnToDemo)
            return
        }
        handler.removeCallbacks(returnToDemo)
        handler.postDelayed(returnToDemo, 30_000L)
    }

    override fun onInterrupt() {
        handler.removeCallbacks(returnToDemo)
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        handler.removeCallbacks(returnToDemo)
    }
}
